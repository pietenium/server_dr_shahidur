You are a **Senior Enterprise Node.js Architect** with 20+ years of experience building production-grade, scalable, and secure REST APIs using **TypeScript**. You follow **MVC architecture strictly**, write **fully typed, clean, readable, and maintainable code**, and apply **enterprise-level security, validation, and error handling** in every layer. You never take shortcuts. You never use `any` as a type — every value, parameter, return type, and object shape is explicitly typed.

You are building the **entire backend API** for a **Doctor's Personal Web Platform** — for Dr. Md. Sahidur Rahman Khan, an Orthopedic Surgeon and Public Figure. This backend will serve **two separate frontends**: a **Next.js public website** and a **Vite + React dashboard**. The backend is a single unified REST API built entirely in TypeScript and compiled to JavaScript for production.

---

## SECTION 1 — TECHNOLOGY STACK & PACKAGE DECISIONS

Use the following **exact packages** and no others unless a gap requires it. Install everything at the latest stable version with **zero known vulnerabilities**. Every package that ships its own types uses them directly. Every package that does not ship types gets its `@types/` counterpart installed as a dev dependency.

**Core:**

- `express` + `@types/express`
- `mongoose` — ships its own types natively, no @types needed
- `dotenv` + `@types/dotenv`
- `cors` + `@types/cors`
- `helmet`
- `compression` + `@types/compression`
- `morgan` + `@types/morgan`

**Auth & Security:**

- `jsonwebtoken` + `@types/jsonwebtoken`
- `bcrypt` + `@types/bcrypt`
- `express-rate-limit`
- `express-mongo-sanitize` + `@types/express-mongo-sanitize`
- `xss` + `@types/xss`
- `uuid` + `@types/uuid`
- `cookie-parser` + `@types/cookie-parser`

**Validation:**

- `express-validator`

**File Handling:**

- `multer` + `@types/multer`
- `@imagekit/nodejs` — for images and PDFs
- `cloudinary` — for videos only

**Email:**

- `nodemailer` + `@types/nodemailer`

**Redis:**

- `ioredis` — the most mature, fully-typed Redis client for Node.js. Ships its own TypeScript types natively. Used for: refresh token blacklisting on logout, OTP/magic token caching, rate limit store, and public endpoint response caching.

**Utility:**

- `dayjs`
- `mongoose-paginate-v2` + `@types/mongoose-paginate-v2`
- `chalk` — use version **4.x** only (CommonJS compatible — never v5, which is ESM-only)
- `socket.io`

**TypeScript Compiler & Dev Tools:**

- `typescript` — devDependency
- `ts-node` — devDependency
- `ts-node-dev` — devDependency, replaces nodemon
- `tsconfig-paths` — devDependency, resolves path aliases at runtime
- `@types/node` — devDependency

**Additional packages — research and choose best zero-vulnerability version:**

- Google reCAPTCHA v3 server-side verification — use `axios`. No reCAPTCHA-specific package needed.
- IP geolocation — use `axios` to query `https://ipwho.is/{ip}`.
- Slugify — `slugify` package + `@types/slugify` if not bundled. Must handle Bangla text.
- Environment variable schema validation — **`zod`** — ships its own types, preferred for TypeScript.
- DOI validation — write a lightweight regex utility in `src/utils/validateDOI.ts`. No package needed.

**WhatsApp:**

- `whatsapp-web.js` + `@types/whatsapp-web.js` (community types — install if available, otherwise write local `.d.ts` in `src/types/whatsapp-web.js.d.ts`)
- `qrcode-terminal` + `@types/qrcode-terminal`

**Telegram:**

- `node-telegram-bot-api` + `@types/node-telegram-bot-api`

---

## SECTION 2 — TYPESCRIPT CONFIGURATION

### `tsconfig.json` (root level)

Create a strict, production-ready TypeScript configuration with these compiler options:

- `target`: `ES2020`
- `module`: `commonjs`
- `lib`: `["ES2020"]`
- `rootDir`: `./src`
- `outDir`: `./dist`
- `strict`: `true`
- `noImplicitAny`: `true`
- `strictNullChecks`: `true`
- `noUnusedLocals`: `true`
- `noUnusedParameters`: `true`
- `noImplicitReturns`: `true`
- `esModuleInterop`: `true`
- `allowSyntheticDefaultImports`: `true`
- `resolveJsonModule`: `true`
- `forceConsistentCasingInFileNames`: `true`
- `skipLibCheck`: `true`
- `baseUrl`: `./src`
- `paths`:
  - `@modules/*` → `modules/*`
  - `@middlewares/*` → `middlewares/*`
  - `@utils/*` → `utils/*`
  - `@config/*` → `config/*`
  - `@constants/*` → `constants/*`
  - `@emails/*` → `emails/*`
  - `@types-app/*` → `types/*`
- `include`: `["src/**/*"]`
- `exclude`: `["node_modules", "dist"]`

### `package.json` scripts

```json
{
  "scripts": {
    "dev": "ts-node-dev --respawn --transpile-only -r tsconfig-paths/register src/server.ts",
    "build": "tsc --project tsconfig.json",
    "start": "node -r tsconfig-paths/register dist/server.js",
    "type-check": "tsc --noEmit"
  },
  "main": "dist/server.js"
}
```

The `--transpile-only` flag skips type checking during development for speed. The `type-check` script runs full type checking separately. In production always run `npm run build` then `npm start`.

---

## SECTION 3 — PROJECT FOLDER STRUCTURE

Implement this **exact folder structure**. Every file has a specific, single responsibility. All files use `.ts` extension. Every module has an `interface` file.

```
/
├── src/
│   ├── modules/
│   │   ├── auth/
│   │   │   ├── auth.routes.ts
│   │   │   ├── auth.controller.ts
│   │   │   ├── auth.service.ts
│   │   │   ├── auth.validator.ts
│   │   │   ├── auth.model.ts
│   │   │   └── auth.interface.ts
│   │   ├── analytics/
│   │   │   ├── analytics.routes.ts
│   │   │   ├── analytics.controller.ts
│   │   │   ├── analytics.service.ts
│   │   │   ├── analytics.validator.ts
│   │   │   ├── analytics.model.ts
│   │   │   └── analytics.interface.ts
│   │   ├── appointment/
│   │   │   ├── appointment.routes.ts
│   │   │   ├── appointment.controller.ts
│   │   │   ├── appointment.service.ts
│   │   │   ├── appointment.validator.ts
│   │   │   ├── appointment.model.ts
│   │   │   └── appointment.interface.ts
│   │   ├── article/
│   │   │   ├── article.routes.ts
│   │   │   ├── article.controller.ts
│   │   │   ├── article.service.ts
│   │   │   ├── article.validator.ts
│   │   │   ├── article.model.ts
│   │   │   ├── article-category.model.ts
│   │   │   └── article.interface.ts
│   │   ├── research/
│   │   │   ├── research.routes.ts
│   │   │   ├── research.controller.ts
│   │   │   ├── research.service.ts
│   │   │   ├── research.validator.ts
│   │   │   ├── research.model.ts
│   │   │   └── research.interface.ts
│   │   ├── testimonial/
│   │   │   ├── testimonial.routes.ts
│   │   │   ├── testimonial.controller.ts
│   │   │   ├── testimonial.service.ts
│   │   │   ├── testimonial.validator.ts
│   │   │   ├── testimonial.model.ts
│   │   │   └── testimonial.interface.ts
│   │   ├── activity-log/
│   │   │   ├── activity-log.routes.ts
│   │   │   ├── activity-log.controller.ts
│   │   │   ├── activity-log.service.ts
│   │   │   ├── activity-log.model.ts
│   │   │   └── activity-log.interface.ts
│   │   ├── app-info/
│   │   │   ├── app-info.routes.ts
│   │   │   ├── app-info.controller.ts
│   │   │   ├── app-info.service.ts
│   │   │   ├── app-info.validator.ts
│   │   │   ├── app-info.model.ts
│   │   │   └── app-info.interface.ts
│   │   ├── search/
│   │   │   ├── search.routes.ts
│   │   │   ├── search.controller.ts
│   │   │   ├── search.service.ts
│   │   │   ├── search.validator.ts
│   │   │   └── search.interface.ts
│   │   └── contact/
│   │       ├── contact.routes.ts
│   │       ├── contact.controller.ts
│   │       ├── contact.service.ts
│   │       ├── contact.validator.ts
│   │       ├── contact.model.ts       ← Contact messages saved to DB
│   │       └── contact.interface.ts
│   ├── middlewares/
│   │   ├── auth.middleware.ts
│   │   ├── role.middleware.ts
│   │   ├── activity-log.middleware.ts
│   │   ├── recaptcha.middleware.ts
│   │   ├── upload.middleware.ts
│   │   └── error.middleware.ts
│   ├── config/
│   │   ├── db.ts
│   │   ├── env.ts
│   │   ├── redis.ts               ← Redis client singleton
│   │   ├── imagekit.ts            ← Images and PDFs
│   │   ├── cloudinary.ts          ← Videos only
│   │   ├── nodemailer.ts
│   │   └── cors.ts
│   ├── utils/
│   │   ├── ApiResponse.ts
│   │   ├── ApiError.ts
│   │   ├── asyncHandler.ts
│   │   ├── slugify.ts
│   │   ├── generateOTP.ts
│   │   ├── generateToken.ts
│   │   ├── getGeoLocation.ts
│   │   ├── sanitizeHtml.ts
│   │   ├── sendWhatsApp.ts
│   │   ├── sendTelegram.ts
│   │   └── validateDOI.ts
│   ├── emails/
│   │   ├── templates/
│   │   │   ├── otp-email.template.ts
│   │   │   ├── magic-login.template.ts
│   │   │   ├── moderator-invite.template.ts
│   │   │   ├── appointment-confirmation.template.ts
│   │   │   └── contact-confirmation.template.ts
│   │   └── sendEmail.ts
│   ├── constants/
│   │   ├── roles.constant.ts
│   │   ├── status.constant.ts
│   │   └── messages.constant.ts
│   ├── types/
│   │   ├── express.d.ts
│   │   ├── global.types.ts
│   │   └── whatsapp-web.js.d.ts
│   └── app.ts
├── server.ts
├── tsconfig.json
├── .env
├── .env.example
├── .gitignore
└── package.json
```

---

## SECTION 4 — GLOBAL TYPE DECLARATIONS

Build every file in `src/types/` before writing any other code.

### `src/types/express.d.ts`

Augments Express's `Request` type globally so `req.user` is typed throughout the entire application.

Declare a module augmentation for `express-serve-static-core`. Add a `user` property:

```typescript
interface AuthenticatedUser {
  _id: string;
  email: string;
  name: string;
  role: "ADMIN" | "MODERATOR";
}
```

The `user` property on `Request` must be typed as `AuthenticatedUser | undefined`. Also augment `Request` with a typed `file` and `files` map for multer uploads.

### `src/types/global.types.ts`

Define reusable shared types used across multiple modules:

- `GeoLocation`: `{ country: string; region: string; city: string; lat: number; lon: number; ip: string }`
- `PaginationMeta`: `{ totalDocs: number; totalPages: number; currentPage: number; limit: number; hasNextPage: boolean; hasPrevPage: boolean }`
- `PaginatedResult<T>`: `{ results: T[]; pagination: PaginationMeta }`
- `ApiSuccessResponse<T>`: `{ success: true; statusCode: number; message: string; data: T }`
- `ApiErrorResponse`: `{ success: false; statusCode: number; message: string; errors: Array<{ field?: string; message: string }> }`
- `OgImage`: `{ url: string; fileId: string }`
- `RedisCacheKey` — a string union type of all cache key prefixes used in the project: `'app-info'`, `'articles-list'`, `'research-list'`, `'article-slug'`, `'research-slug'`, `'testimonials-list'`. This ensures cache keys are never hardcoded as free-form strings anywhere in the codebase.

### `src/types/whatsapp-web.js.d.ts`

If `@types/whatsapp-web.js` is not available or has known issues, write a minimal local declaration file. Declare the module `'whatsapp-web.js'` and export the types needed: `Client`, `LocalAuth`, `Message`. Type them specifically enough to avoid using `any`. If the community types package is available and maintained, install it instead and skip this file — but verify first.

---

## SECTION 5 — INTERFACE FILES (ONE PER MODULE)

Every module's `.interface.ts` file is the **single source of truth** for all types in that module. Models, services, controllers, and validators all import from this file. Never define inline types in model or controller files.

### `auth.interface.ts`

- `IUser` — full Mongoose document interface. Fields: `name`, `email`, `password`, `role`, `isActive`, `otpCode`, `otpExpiry`, `magicLoginToken`, `magicLoginExpiry`, `lastLogin`.
- `IUserMethods` — instance method types including `comparePassword(candidatePassword: string): Promise<boolean>`
- `UserModel` — `Model<IUser, {}, IUserMethods>` with paginate plugin merged
- `LoginPayload` — `{ email: string; password: string }`
- `ForgotPasswordPayload` — `{ email: string }`
- `VerifyOtpPayload` — `{ email: string; otp: string }`
- `MagicLoginPayload` — `{ email: string; magicToken: string }`
- `ResetPasswordPayload` — `{ email: string; magicToken: string; newPassword: string }`
- `JwtAccessPayload` — `{ _id: string; role: 'ADMIN' | 'MODERATOR' }`
- `JwtRefreshPayload` — `{ _id: string }`
- `AuthTokens` — `{ accessToken: string; refreshToken: string }`

### `analytics.interface.ts`

- `IAnalytics` — document interface with all model fields
- `TrackPageViewPayload` — `{ page: string; sessionId: string }`
- `GeoAggregationResult` — for location aggregation query results
- `PageViewAggregationResult` — for page view aggregation results

### `appointment.interface.ts`

- `IAppointment` — document interface. Fields: `name`, `phone`, `email`, `message`, `preferredDate`, `preferredTime`, `status`, `ipAddress`, `location`, `timestamps`. Note: there is NO `smsLog` field — SMS has been removed from this project.
- `CreateAppointmentPayload` — all public form fields
- `AppointmentFilterQuery` — `{ status?: string; startDate?: string; endDate?: string; search?: string; page?: number; limit?: number }`
- `AppointmentChartData` — shape of the chart data response

### `article.interface.ts`

- `IArticleCategory` — document interface
- `IArticle` — document interface. The `category` field typed as `Types.ObjectId | IArticleCategory`
- `CreateArticlePayload` — all creation fields
- `UpdateArticlePayload` — `Partial<CreateArticlePayload>`
- `ArticleFilterQuery` — query params shape
- `ArticleType` — `'medical' | 'political'`

### `research.interface.ts`

- `IResearch` — document interface
- `UploadType` — `'pdf' | 'doi'`
- `CreateResearchPayload` — all creation fields
- `UpdateResearchPayload` — Partial version
- `ResearchFilterQuery` — query params

### `testimonial.interface.ts`

- `ITestimonial` — document interface
- `CreateTestimonialPayload` — all creation fields
- `UpdateTestimonialPayload` — Partial version

### `activity-log.interface.ts`

- `IActivityLog` — document interface. The `user` field typed as `Types.ObjectId | IUser`
- `CreateLogPayload` — shape of what the middleware sends to the service
- `LogFilterQuery` — for admin queries
- `BulkDeletePayload` — `{ ids: string[] }`

### `app-info.interface.ts`

- `IAppInfo` — document interface
- `UpdateAppInfoPayload` — all fields as optional

### `contact.interface.ts`

- `IContact` — full Mongoose document interface. Fields: `name`, `email`, `phone` (optional), `subject`, `message`, `reason`, `ipAddress`, `location` (GeoLocation object), `isRead` (boolean, default false), `telegramMessageId` (number, optional — the Telegram message ID returned by the bot after successful delivery, stored for reference), `timestamps`.
- `ContactReason` — `'medical-inquiry' | 'general' | 'media' | 'other'`
- `CreateContactPayload` — all public form fields
- `ContactFilterQuery` — `{ isRead?: boolean; reason?: ContactReason; page?: number; limit?: number }`

### `search.interface.ts`

- `SearchQuery` — `{ q: string; type?: 'article' | 'research' | 'testimonial'; limit?: number }`
- `ArticleSearchResult` — exact shape of a returned article result with `resultType: 'article'`
- `ResearchSearchResult` — exact shape of a returned research result with `resultType: 'research'`
- `TestimonialSearchResult` — exact shape of a returned testimonial result with `resultType: 'testimonial'`
- `UniversalSearchResult` — full response shape with `query`, `totalResults`, and `results` object

---

## SECTION 6 — ENVIRONMENT VARIABLES & VALIDATION

Define every variable in `.env.example` with a descriptive comment. In `src/config/env.ts`, use **`zod`** to define a strict schema. The application must crash with a formatted error listing every missing/invalid variable at startup — never silently fail.

Export the validated config as a typed constant. Every other file imports from `@config/env` — no file ever reads `process.env` directly except `env.ts`. The exported type is inferred via `z.infer<typeof envSchema>`.

**Required variables:**

```env
# ─── SERVER ──────────────────────────────────────────────────────────
PORT=5000                                 # z.coerce.number()
NODE_ENV=development                      # z.enum(['development','production','test'])

# ─── DATABASE ────────────────────────────────────────────────────────
MONGO_URI=mongodb+srv://...

# ─── REDIS ───────────────────────────────────────────────────────────
REDIS_URL=redis://localhost:6379          # Full Redis connection URL
# OR use individual fields if preferred:
# REDIS_HOST=localhost
# REDIS_PORT=6379
# REDIS_PASSWORD=your_redis_password      # Optional, for secured Redis
# REDIS_TLS=false                         # z.coerce.boolean(), set true for cloud Redis

# ─── JWT ─────────────────────────────────────────────────────────────
JWT_ACCESS_SECRET=your_access_secret_min_32_chars
JWT_REFRESH_SECRET=your_refresh_secret_min_32_chars
JWT_ACCESS_EXPIRY=15m
JWT_REFRESH_EXPIRY=7d

# ─── CORS ────────────────────────────────────────────────────────────
CLIENT_PUBLIC_URL=https://www.domain.com
CLIENT_DASHBOARD_URL=https://dashboard.domain.com

# ─── IMAGEKIT (images + PDFs) ────────────────────────────────────────
IMAGEKIT_PUBLIC_KEY=public_xxxxxxxxxxxx
IMAGEKIT_PRIVATE_KEY=private_xxxxxxxxxxxx
IMAGEKIT_URL_ENDPOINT=https://ik.imagekit.io/yourid

# ─── CLOUDINARY (videos only) ────────────────────────────────────────
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret

# ─── EMAIL (SMTP) ────────────────────────────────────────────────────
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587                             # z.coerce.number()
SMTP_USER=your@email.com
SMTP_PASS=your_app_password
SMTP_FROM_NAME=Dr. Sahidur Rahman Khan
SMTP_FROM_EMAIL=no-reply@domain.com

# ─── GOOGLE RECAPTCHA V3 ─────────────────────────────────────────────
RECAPTCHA_V3_SECRET=your_recaptcha_v3_secret_key

# ─── WHATSAPP ────────────────────────────────────────────────────────
DOCTOR_WHATSAPP_NUMBER=880xxxxxxxxxx      # No + prefix, no spaces
WHATSAPP_SESSION_PATH=./whatsapp-session

# ─── TELEGRAM ────────────────────────────────────────────────────────
TELEGRAM_BOT_TOKEN=xxxxxxxxxx:xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TELEGRAM_CHAT_ID=xxxxxxxxxx

# ─── ADMIN SEED ──────────────────────────────────────────────────────
ADMIN_SEED_EMAIL=admin@domain.com
ADMIN_SEED_PASSWORD=StrongPassword@123
```

---

## SECTION 7 — REDIS CONFIGURATION & USAGE STRATEGY

### `src/config/redis.ts`

Create a **singleton** `ioredis` client. Export a single `redisClient` instance. The client connects using `REDIS_URL` from env. Configure:

- `lazyConnect: false` — connect immediately on import
- `maxRetriesPerRequest: 3`
- `retryStrategy` — exponential backoff, max 3 retries, then return null (do not crash)
- `enableReadyCheck: true`

On `connect` event: log chalk green "Redis connected successfully."
On `error` event: log chalk red "Redis error: {message}" — do NOT crash the process. Redis failures are non-fatal and the application must continue operating without cache if Redis is unavailable.
On `close` event: log chalk yellow "Redis connection closed."

Export a typed `isRedisReady(): boolean` helper function that checks the client's status before any operation.

### Redis Usage Map — Apply These Exactly

Redis is used in **four specific ways** across the project. Do not use Redis for anything outside this list without a clear reason.

**1. Refresh Token Blacklisting (Auth Security)**

When a user logs out (`POST /api/v1/auth/logout`), the current refresh token's JTI (JWT ID) is added to a Redis blacklist with a TTL equal to the token's remaining lifetime. On every `POST /api/v1/auth/refresh-token` request, before issuing a new token, check the Redis blacklist for the incoming token's JTI. If it exists, reject with `401`. This prevents refresh token reuse after logout.

To implement this: add a `jti` (UUID) claim to the refresh token payload. When generating refresh tokens, include the jti. Store it in Redis as: key = `blacklist:jti:{jti}`, value = `'1'`, TTL = remaining seconds of the refresh token lifetime.

The `JwtRefreshPayload` interface in `auth.interface.ts` must be updated to include `jti: string`.

**2. OTP & Magic Token Caching (Auth Flow)**

Instead of storing OTP codes and magic tokens in the MongoDB User document (which requires a DB write and DB read on every verification), store them in Redis for the 10-minute window they are valid.

- Store OTP: key = `otp:{userId}`, value = hashed OTP string, TTL = 600 seconds
- Store magic token: key = `magic:{userId}`, value = hashed magic token string, TTL = 600 seconds

On verification, read from Redis. On use (magic-login or reset-password), delete from Redis immediately. This eliminates the `otpCode`, `otpExpiry`, `magicLoginToken`, and `magicLoginExpiry` fields from the MongoDB User model entirely — they are no longer needed in the database. Update `auth.interface.ts` accordingly — remove these four fields from `IUser`.

**3. Public Endpoint Response Caching**

Cache responses for high-traffic public GET endpoints that change infrequently. Use the following TTLs:

- `GET /api/v1/app-info` → cache key: `cache:app-info`, TTL: 3600 seconds (1 hour)
- `GET /api/v1/articles` (published list) → cache key: `cache:articles:{queryHash}`, TTL: 300 seconds (5 minutes). The `queryHash` is a deterministic hash of the query params string so different filter combinations are cached separately.
- `GET /api/v1/research` (published list) → cache key: `cache:research:{queryHash}`, TTL: 300 seconds
- `GET /api/v1/testimonials` (visible list) → cache key: `cache:testimonials`, TTL: 600 seconds (10 minutes)
- `GET /api/v1/articles/:slug` → cache key: `cache:article:{slug}`, TTL: 600 seconds
- `GET /api/v1/research/:slug` → cache key: `cache:research-slug:{slug}`, TTL: 600 seconds

**Cache invalidation rules:** When an article, research paper, or testimonial is created, updated, or deleted via a protected route, the corresponding cache keys must be deleted from Redis. This happens in the service layer, after the MongoDB operation succeeds, before returning. Use `redisClient.del(key)` for specific keys and `redisClient.keys('cache:articles:*')` with a pipeline delete for pattern-based invalidation.

Build a typed cache utility in `src/utils/cache.ts`:

```typescript
getCache<T>(key: string): Promise<T | null>
setCache<T>(key: string, data: T, ttlSeconds: number): Promise<void>
deleteCache(key: string): Promise<void>
deleteCachePattern(pattern: string): Promise<void>
```

All four functions must handle Redis unavailability gracefully — wrap in try/catch, log the error with chalk, and return null / resolve without throwing. A cache miss must never crash the application.

**4. Rate Limiting Store (express-rate-limit)**

Use Redis as the backing store for `express-rate-limit` instead of the default in-memory store. This ensures rate limits persist across server restarts and work correctly in multi-process/multi-instance deployments. Use `rate-limit-redis` package (install it) which provides a `RedisStore` compatible with `ioredis`. Pass the `redisClient` instance to the `RedisStore`.

Apply this to all rate limiter instances in the project. If Redis is unavailable, `rate-limit-redis` falls back to in-memory automatically — do not add custom fallback logic for this.

---

## SECTION 8 — APPLICATION ENTRY POINTS

### `server.ts`

Top-level entry. Startup sequence — sequential, async/await, fail-fast:

```
validateEnv (zod — crashes if invalid)
  → connectDB()          [MongoDB]
  → connectRedis()       [Redis — non-fatal if fails, logs warning]
  → seedAdmin()
  → initWhatsApp()
  → app.listen()
```

Redis connection failure is **non-fatal** — log a chalk yellow warning and continue. MongoDB failure IS fatal — call `process.exit(1)`.

### `src/app.ts`

Configure the Express application. Apply middlewares in this exact order:

1. `helmet()` with a strict Content Security Policy
2. `cors()` with config from `config/cors.ts`
3. `compression()`
4. `express.json({ limit: '10mb' })`
5. `express.urlencoded({ extended: true, limit: '10mb' })`
6. `cookieParser()`
7. `mongoSanitize()`
8. `morgan` (development only — chalk colorized)
9. All module routers mounted under `/api/v1/`
10. 404 handler
11. Global error handler (last)

Export typed as `express.Application`.

---

## SECTION 9 — UTILITIES

Build every utility with full TypeScript typing. No implicit `any` anywhere.

### `ApiResponse.ts`

Generic class `ApiResponse<T>`. Constructor: `(statusCode: number, message: string, data: T)`. Method: `send(res: Response): void`. Use `new ApiResponse(200, 'Success', data).send(res)` in every controller.

### `ApiError.ts`

Class extending `Error`. Constructor: `(statusCode: number, message: string, errors: Array<{field?: string; message: string}> = [])`. Properties: `statusCode: number`, `isOperational: boolean` (always `true`).

### `asyncHandler.ts`

```typescript
type AsyncHandler = (
  req: Request,
  res: Response,
  next: NextFunction,
) => Promise<void>;
const asyncHandler =
  (fn: AsyncHandler) =>
  (req: Request, res: Response, next: NextFunction): void => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
```

### `generateToken.ts`

- `generateAccessToken(payload: JwtAccessPayload): string`
- `generateRefreshToken(payload: JwtRefreshPayload): string` — the refresh token payload now includes `jti: string` (UUID generated at call time). The JTI is used for blacklisting on logout.
- `generateTokenJti(): string` — generates a UUID for the JTI field. Called inside `generateRefreshToken`.

### `getGeoLocation.ts`

Signature: `getGeoLocation(ip: string): Promise<GeoLocation>`. Uses `axios`. Returns default object with `'unknown'`/`0` values on failure. Never throws.

### `generateOTP.ts`

Returns `string`. Uses `crypto.randomInt(100000, 999999).toString()`.

### `slugify.ts`

Signature: `generateSlug(text: string, fallbackId?: string): string`. Uses `slugify` package. Falls back to UUID suffix for untransliteratable Bangla text.

### `sanitizeHtml.ts`

Signature: `sanitizeContent(html: string): string`. Uses `xss` package with strict `xss.IWhiteList` config.

### `validateDOI.ts`

- `validateDOI(doi: string): boolean` — regex `/^10\.\d{4,9}\/[-._;()/:A-Z0-9]+$/i`
- `normalizeDOI(doi: string): string` — prepends `https://doi.org/` if not present

### `cache.ts`

Build the four cache utility functions using `redisClient` from `config/redis.ts`:

- `getCache<T>(key: string): Promise<T | null>` — JSON.parse the stored value. Return null on miss or error.
- `setCache<T>(key: string, data: T, ttlSeconds: number): Promise<void>` — JSON.stringify before storing. Use `SET key value EX ttl`.
- `deleteCache(key: string): Promise<void>` — single key deletion.
- `deleteCachePattern(pattern: string): Promise<void>` — use `KEYS pattern` then pipeline delete. Add a developer comment: "KEYS is acceptable here because cache invalidation is low-frequency (triggered by admin writes, not user reads). In a high-write production environment, replace with SCAN for non-blocking iteration."

All four wrap in try/catch and log errors with chalk without throwing.

### `sendWhatsApp.ts`

Full singleton implementation using `whatsapp-web.js`. Exports:

- `initWhatsApp(): void`
- `sendWhatsAppMessage(phone: string, message: string): Promise<void>`

The `isReady` flag is a module-level `let boolean`. On `disconnected` event: attempt re-initialization after 5 seconds. Never crash the application. If `whatsapp-web.js` types are unavailable, use `// @ts-expect-error` with a written justification comment.

### `sendTelegram.ts`

Full singleton using `node-telegram-bot-api` with `polling: false`. Exports:

- `sendTelegramMessage(message: string): Promise<{ success: boolean; telegramMessageId?: number; error?: string }>`
  — Note the return type includes `telegramMessageId` (the `message_id` returned by Telegram's API after successful delivery). This ID is stored in the Contact document for reference.
- `formatAppointmentMessage(appointment: IAppointment): string`
- `formatContactMessage(contact: IContact): string`

The `sendTelegramMessage` function must return the `telegramMessageId` from the Telegram API response when successful. The contact service uses this to store the ID in the database. On failure, return `{ success: false, error }` — never throw.

---

## SECTION 10 — CONSTANTS

### `roles.constant.ts`

```typescript
export const ROLES = {
  ADMIN: "ADMIN",
  MODERATOR: "MODERATOR",
} as const;
export type Role = (typeof ROLES)[keyof typeof ROLES];
```

### `status.constant.ts`

`as const` pattern for:

- `APPOINTMENT_STATUS`: `PENDING`, `CONFIRMED`, `CANCELLED`
- `CONTENT_STATUS`: `DRAFT`, `PUBLISHED`
- `UPLOAD_TYPE`: `PDF`, `DOI`
- `ARTICLE_TYPE`: `MEDICAL`, `POLITICAL`

Export derived types: `AppointmentStatus`, `ContentStatus`, `UploadType`, `ArticleType`.

### `messages.constant.ts`

`Record<string, string>` typed message groups for every module: `AUTH_MESSAGES`, `ARTICLE_MESSAGES`, `RESEARCH_MESSAGES`, `APPOINTMENT_MESSAGES`, `TESTIMONIAL_MESSAGES`, `CONTACT_MESSAGES`, `LOG_MESSAGES`, `SEARCH_MESSAGES`, `APP_INFO_MESSAGES`, `USER_MESSAGES`. Never hardcode message strings in controllers or services.

---

## SECTION 11 — MIDDLEWARE

All middleware uses explicit `RequestHandler`, `ErrorRequestHandler` signatures.

### `auth.middleware.ts`

`const authenticate: RequestHandler`. Extracts Bearer token. Verifies as `JwtAccessPayload`. Also checks Redis blacklist for the token's JTI — if found, reject with `401 ApiError` ("Session has been invalidated. Please log in again."). Attaches decoded payload to `req.user`. Returns `401 ApiError` on any failure.

### `role.middleware.ts`

`const authorize = (...roles: Role[]): RequestHandler`. Returns `403 ApiError` if role not permitted.

### `activity-log.middleware.ts`

`const logActivity = (module: string): RequestHandler`. Factory function. Fires async log save on `res.on('finish')` if status < 400. Payload typed as `CreateLogPayload`.

### `recaptcha.middleware.ts`

`const verifyRecaptcha: RequestHandler`. Uses `axios`. Typed response `RecaptchaVerifyResponse`. Rejects if score < `0.5`.

### `upload.middleware.ts`

`multer.memoryStorage()`. Exports: `uploadImage`, `uploadPDF`, `uploadVideo`, `uploadImageAndVideo`. All MIME types in a `readonly string[]` constant. `fileFilter` typed as `multer.FileFilterCallback`.

### `error.middleware.ts`

`const errorHandler: ErrorRequestHandler`. Handles `ApiError`, `mongoose.Error.ValidationError`, `mongoose.Error.CastError`, `JsonWebTokenError`, `TokenExpiredError`. Generic `500` in production. Stack trace in development.

---

## SECTION 12 — MODULE ARCHITECTURE RULES

**Model (`.model.ts`):** `Schema<IModuleName>`, `PaginateModel<IModuleName>`, `.toJSON({ transform })` strips sensitive fields, `schema.index({})` for all queried fields.

**Service (`.service.ts`):** All params and return types explicit. Throws `ApiError`. Never returns null silently. Handles cache invalidation after write operations.

**Controller (`.controller.ts`):** `asyncHandler` on every method. Calls service only. `new ApiResponse<T>(...).send(res)`. No business logic.

**Validator (`.validator.ts`):** `ValidationChain[]`. Ends with `checkValidationResult`.

**Routes (`.routes.ts`):** Chain order: `[validator, authenticate, authorize(...roles), logActivity(module), controller]`.

---

## SECTION 13 — AUTH MODULE

### User Model

Remove `otpCode`, `otpExpiry`, `magicLoginToken`, `magicLoginExpiry` from the MongoDB schema entirely. These are now stored in Redis. The model only contains: `name`, `email`, `password`, `role`, `isActive`, `lastLogin`, `timestamps`.

Update `IUser` in `auth.interface.ts` accordingly.

### Endpoints

**POST /api/v1/auth/login**

- Validate email and password
- Find user by email, check `isActive`
- `comparePassword()` instance method
- Generate access token and refresh token (refresh token includes `jti`)
- Set refresh token as HttpOnly, Secure, SameSite=Strict cookie
- Return access token + user info
- Log activity

**POST /api/v1/auth/forgot-password**

- Validate email
- Find user (respond with generic success even if not found — never leak existence)
- Generate 6-digit OTP with `generateOTP()`
- Generate UUID magic token
- Hash both with bcrypt
- Store in Redis: `otp:{userId}` and `magic:{userId}` — TTL 600 seconds each
- Send email with OTP code + magic login button linking to dashboard

**POST /api/v1/auth/verify-otp**

- Validate email and OTP
- Find user by email
- Read hashed OTP from Redis key `otp:{userId}`
- Compare with bcrypt. Check that the key exists (TTL not expired).
- On success: retrieve raw magic token from session context (the service must store the raw magic token temporarily — read the hashed magic token from Redis key `magic:{userId}` and return it as-is so the frontend can present the two options)
- Do NOT delete Redis keys yet

**POST /api/v1/auth/magic-login**

- Accepts `{ email, magicToken }`
- Find user, read `magic:{userId}` from Redis
- Compare hashed magic token with bcrypt. Verify key exists.
- On success: delete `otp:{userId}` and `magic:{userId}` from Redis. Update `lastLogin`. Generate full auth tokens. Return tokens.
- On failure: `401`

**POST /api/v1/auth/reset-password**

- Accepts `{ email, magicToken, newPassword }`
- Validate magic token via Redis `magic:{userId}` — same comparison as above
- Hash new password, save to MongoDB
- Delete `otp:{userId}` and `magic:{userId}` from Redis
- Return success. Send password-changed confirmation email. Do NOT auto-login.

**POST /api/v1/auth/refresh-token**

- Read refresh token from HttpOnly cookie
- Verify JWT. Extract `jti` from payload.
- Check Redis blacklist `blacklist:jti:{jti}` — if exists, reject `401`
- Issue new access token + new refresh token (new JTI — rotation)
- Blacklist old JTI in Redis with TTL = remaining lifetime of old token
- Update cookie with new refresh token

**POST /api/v1/auth/logout**

- Protected route
- Extract JTI from current refresh token cookie
- Add JTI to Redis blacklist: `blacklist:jti:{jti}`, TTL = remaining lifetime
- Clear the cookie
- Return `200`

---

## SECTION 14 — ANALYTICS MODULE

Implement all endpoints. Aggregation pipeline arrays typed as `mongoose.PipelineStage[]`. Results typed with `GeoAggregationResult` and `PageViewAggregationResult` from `analytics.interface.ts`. The `POST /api/v1/analytics/track` endpoint is rate-limited (60/min per IP, Redis-backed store) and fire-and-forget.

---

## SECTION 15 — APPOINTMENT MODULE

### Model Fields

`name`, `phone`, `email`, `message`, `preferredDate`, `preferredTime`, `status` (enum: pending/confirmed/cancelled, default pending), `ipAddress`, `location` (GeoLocation object), `timestamps`.

**There is no `smsLog` field. There is no SMS sending anywhere in this module.**

### Endpoints

**POST /api/v1/appointments** — Public

- Apply `recaptcha.middleware.ts`
- Validate: name (required), phone (required, valid BD format +880), email (optional, valid if provided), preferredDate (required, future date), preferredTime (required), message (optional)
- Save appointment, resolve geolocation async
- Send confirmation email to patient (if email provided) — non-blocking
- Send WhatsApp message to doctor — non-blocking

WhatsApp message format (sent to doctor only — never to patient):

```
🗓 *New Appointment Request*

👤 *Patient:* {name}
📞 *Phone:* {phone}
📧 *Email:* {email || 'Not provided'}
📅 *Preferred Date:* {dayjs formatted date}
⏰ *Preferred Time:* {time}
💬 *Message:* {message || 'No message'}
📍 *Location:* {city}, {country}
🕐 *Submitted:* {dayjs timestamp}

Manage via dashboard.
```

Both notifications use `Promise.allSettled` — never block the HTTP response.

**GET /api/v1/appointments** — Protected, ADMIN/MODERATOR

- Paginated. Filter: `status`, date range, search by name or phone.

**GET /api/v1/appointments/charts** — Protected, ADMIN/MODERATOR

- Daily count last 30 days, monthly count last 12 months, all-time total, status distribution.

**GET /api/v1/appointments/:id** — Protected, ADMIN/MODERATOR

**PATCH /api/v1/appointments/:id/status** — Protected, ADMIN/MODERATOR

- Update status to `confirmed` or `cancelled`. Log activity.

> There is NO `POST /api/v1/appointments/:id/sms` endpoint. SMS has been removed entirely.

---

## SECTION 16 — ARTICLE MODULE

### Cache Integration

In the article service, after any successful create/update/delete operation:

- Call `deleteCachePattern('cache:articles:*')` to invalidate all article list caches
- Call `deleteCache('cache:article:{slug}')` to invalidate the specific article cache

In the public GET endpoints:

- Check cache first using `getCache<T>(key)`
- On cache hit: return cached data directly (do not query MongoDB)
- On cache miss: query MongoDB, then `setCache(key, data, ttl)` before returning

### Endpoints

All from original prompt. TipTap content sanitized via `sanitizeContent()` in service layer. `impressions` increment via atomic `findOneAndUpdate`. Category CRUD with 409 guard if articles reference the category.

---

## SECTION 17 — RESEARCH MODULE

### Cache Integration

Same pattern as articles. After create/update/delete:

- `deleteCachePattern('cache:research:*')`
- `deleteCache('cache:research-slug:{slug}')`

### Endpoints

All from original prompt. Discriminated union for `pdf` vs `doi` upload type. ImageKit PDF deletion before document deletion.

---

## SECTION 18 — TESTIMONIAL MODULE

### Cache Integration

After create/update/delete: `deleteCache('cache:testimonials')`.

### Endpoints

All from original prompt. Image on ImageKit, video on Cloudinary. Delete assets before deleting document.

---

## SECTION 19 — ACTIVITY LOG MODULE

All endpoints from original prompt. Role-scoped — MODERATOR sees only own logs. Bulk delete validates ownership. Fire-and-forget writes via middleware.

---

## SECTION 20 — APP INFO MODULE

### Cache Integration

After PATCH update: `deleteCache('cache:app-info')`.
On `GET /api/v1/app-info`: check `cache:app-info` first. Cache TTL: 3600 seconds.

### Endpoints

Singleton document. `GET` public (cached). `PATCH` admin only (invalidates cache, replaces OG image on ImageKit).

---

## SECTION 21 — CONTACT MODULE

This module does **two things** when a contact message is submitted: it saves the message to MongoDB **and** sends a Telegram notification to the doctor. Both happen. The contact form is not Telegram-only.

### Contact Model Fields

`name`, `email`, `phone` (optional), `subject`, `message`, `reason` (enum), `ipAddress`, `location` (GeoLocation), `isRead` (boolean, default false), `telegramMessageId` (Number, optional — stores the message_id returned by Telegram API after successful delivery), `timestamps`.

Apply `mongoose-paginate-v2`. Index: `isRead`, `reason`, `createdAt`.

### Endpoints

**POST /api/v1/contact** — Public

- Apply `recaptcha.middleware.ts`
- Validate: name (required), email (required, valid), phone (optional), subject (required), message (required, min 10 chars), reason (required, enum)
- Save contact document to MongoDB
- Resolve geolocation async
- Send confirmation email to the sender — non-blocking
- Send Telegram message to doctor via `sendTelegramMessage(formatContactMessage(contact))` — non-blocking
  - If Telegram delivery succeeds, update the saved document with the returned `telegramMessageId`: `Contact.findByIdAndUpdate(contact._id, { telegramMessageId: result.telegramMessageId })`
  - This update is fire-and-forget — do NOT await it in the response flow
- Return `201` success immediately after save

Telegram message format:

```html
📩 <b>New Contact Message</b>

👤 <b>Name:</b> {name} 📧 <b>Email:</b> {email} 📞 <b>Phone:</b> {phone || 'Not
provided'} 🏷 <b>Subject:</b> {subject} 📋 <b>Reason:</b> {reason} 💬
<b>Message:</b> {message} 📍 <b>Location:</b> {city}, {country} 🕐
<b>Received:</b> {dayjs timestamp}
```

**GET /api/v1/contact** — Protected, ADMIN/MODERATOR

- Paginated. Filter: `?isRead=`, `?reason=`. Sort newest first.
- Returns all contact messages from MongoDB (not Telegram).

**PATCH /api/v1/contact/:id/read** — Protected, ADMIN/MODERATOR

- Marks `isRead: true`.

**DELETE /api/v1/contact/:id** — Protected, ADMIN only

- Deletes from MongoDB.

---

## SECTION 22 — SEARCH MODULE

### Endpoints

**GET /api/v1/search** — Public, dedicated rate limiter (30/min per IP, Redis-backed)

Service function: `universalSearch(query: SearchQuery): Promise<UniversalSearchResult>`

All three queries run in parallel via `Promise.all`. Each sub-function typed:

- `searchArticles(q: string, limit: number): Promise<ArticleSearchResult[]>`
- `searchResearch(q: string, limit: number): Promise<ResearchSearchResult[]>`
- `searchTestimonials(q: string, limit: number): Promise<TestimonialSearchResult[]>`

Uses `$regex` with `i` flag. `q` under 2 chars returns `400` — no DB query fired.

> Do NOT cache search results in Redis. Search is inherently dynamic and parameterized. Caching would require complex key management for minimal benefit at this scale.

---

## SECTION 23 — USER/MODERATOR MANAGEMENT MODULE

All endpoints from original prompt. `GET /me` omits sensitive fields via `Omit<IUser, 'password'>`. Password change requires `currentPassword` verification. Admin cannot delete self or last remaining admin. Moderator invite sends email via `moderator-invite.template.ts`.

---

## SECTION 24 — EMAIL TEMPLATES

Typed as `type EmailTemplate<T> = (data: T) => string`. Each template exports its own data interface and the function. Inline CSS only. Branding color: `#1a6b4a`.

Templates: `otp-email.template.ts`, `magic-login.template.ts`, `moderator-invite.template.ts`, `appointment-confirmation.template.ts`, `contact-confirmation.template.ts`.

`sendEmail.ts` exports:

```typescript
interface SendEmailOptions { to: string; subject: string; html: string; }
export const sendEmail = async (options: SendEmailOptions): Promise<void>
```

---

## SECTION 25 — RESPONSE FORMAT STANDARD

All responses use `ApiResponse<T>` and `ApiError`. Generic `T` always explicitly specified. Paginated responses wrapped in `PaginatedResult<T>` from `global.types.ts`.

**Success:**

```json
{ "success": true, "statusCode": 200, "message": "...", "data": {} }
```

**Error:**

```json
{ "success": false, "statusCode": 400, "message": "...", "errors": [] }
```

**Paginated:**

```json
{
  "success": true,
  "statusCode": 200,
  "message": "...",
  "data": {
    "results": [],
    "pagination": {
      "totalDocs": 0,
      "totalPages": 0,
      "currentPage": 1,
      "limit": 10,
      "hasNextPage": false,
      "hasPrevPage": false
    }
  }
}
```

---

## SECTION 26 — SECURITY REQUIREMENTS

1. Passwords hashed with bcrypt, salt rounds 12. Never plain text.
2. OTP and magic tokens hashed before Redis storage. Raw values only travel in email — never in API responses.
3. JWT access tokens: 15-minute expiry. Refresh tokens: 7-day expiry, HttpOnly + Secure + SameSite=Strict cookie.
4. Refresh token blacklisting via Redis JTI on logout.
5. Rate limiters use Redis backing store via `rate-limit-redis`. All limiters: auth (10/15min), analytics track (60/min), search (30/min), global (100/15min).
6. File uploads: MIME type validated in multer `fileFilter`. Extension never trusted alone.
7. TipTap HTML sanitized via `sanitizeHtml.ts` in service layer before every save.
8. `express-mongo-sanitize` and `xss` applied globally before routes.
9. `helmet()` with strict CSP as first middleware.
10. CORS strictly whitelisted — exactly two frontend origins, credentials enabled.
11. In production: generic error messages only, no stack traces.
12. Admin seed is idempotent — never creates duplicate.
13. Role enforcement server-side on every protected route.
14. reCAPTCHA v3 server-side score validation (threshold 0.5) on appointment and contact.
15. `req.user` is `AuthenticatedUser | undefined` — every protected controller has a null guard at the top: `if (!req.user) throw new ApiError(401, AUTH_MESSAGES.UNAUTHORIZED)`.
16. Never use type assertions (`as SomeType`) to bypass null checks on security-sensitive values.

---

## SECTION 27 — EXECUTION ORDER

Build in this exact sequence. Complete each step fully before moving to the next.

1. Initialize project — `package.json`, install all dependencies, create full folder structure, `.env`, `.env.example`
2. Write `tsconfig.json` — verify path aliases compile before anything else
3. Build `src/types/` — `express.d.ts`, `global.types.ts`, `whatsapp-web.js.d.ts`
4. Build `src/config/env.ts` with Zod schema — run `type-check` to confirm
5. Build `src/config/redis.ts` — singleton ioredis client
6. Build all interface files — all modules. Zero runtime code, types only. Build ALL before any model.
7. Build all utils: `ApiResponse.ts`, `ApiError.ts`, `asyncHandler.ts`, `slugify.ts`, `generateOTP.ts`, `generateToken.ts`, `getGeoLocation.ts`, `sanitizeHtml.ts`, `validateDOI.ts`, `cache.ts`, `sendWhatsApp.ts`, `sendTelegram.ts`
8. Build all configs: `db.ts`, `imagekit.ts`, `cloudinary.ts`, `nodemailer.ts`, `cors.ts`
9. Build all constants: `roles.constant.ts`, `status.constant.ts`, `messages.constant.ts`
10. Build all middlewares: `error.middleware.ts`, `auth.middleware.ts` (with Redis blacklist check), `role.middleware.ts`, `upload.middleware.ts`, `recaptcha.middleware.ts`, `activity-log.middleware.ts`
11. Build all email templates then `sendEmail.ts`
12. Build `src/app.ts` with all global middleware and router stubs
13. Build `server.ts` with full startup sequence including Redis
14. Build modules in order: **auth → app-info → analytics → appointment → article → research → testimonial → contact → activity-log → users → search**
15. For each module: **interface (already done) → model → validator → service → controller → routes** — register route in `app.ts` immediately. Add cache logic to service.
16. Run `npm run type-check` after each module — zero errors before proceeding
17. Final pass: `npm run type-check` on entire project. Zero errors. Zero `any`. Zero `@ts-ignore`.

---

## SECTION 28 — FINAL QUALITY CHECKLIST

**TypeScript:**

- [ ] `npm run type-check` passes with zero errors
- [ ] Zero uses of `any` type
- [ ] Every public function has explicit return type annotation
- [ ] All interface files built before models and services
- [ ] `req.user` augmented in `express.d.ts`, verified by accessing `req.user.role` without casting
- [ ] All constants use `as const`, derived types used everywhere
- [ ] `tsconfig-paths/register` in both `dev` and `start` scripts
- [ ] `dist/` in `.gitignore`
- [ ] All `@ts-expect-error` have written justification above them

**Redis:**

- [ ] `ioredis` singleton in `config/redis.ts` — one instance, shared everywhere
- [ ] Redis failure is non-fatal — app continues without cache
- [ ] `cache.ts` utility wraps all Redis ops in try/catch
- [ ] OTP and magic tokens stored in Redis, NOT in MongoDB User model
- [ ] `otpCode`, `otpExpiry`, `magicLoginToken`, `magicLoginExpiry` removed from User schema entirely
- [ ] Refresh token JTI blacklisted in Redis on logout
- [ ] Auth middleware checks Redis blacklist before accepting refresh token
- [ ] Public endpoints (app-info, articles, research, testimonials, article slug, research slug) check cache before DB query
- [ ] Cache invalidated after every write operation in service layer
- [ ] Rate limiters all use `rate-limit-redis` backed by `ioredis` instance
- [ ] Search results NOT cached — intentional

**Auth:**

- [ ] Magic-login flow stores tokens in Redis, not DB
- [ ] Logout blacklists JTI with correct TTL (remaining token lifetime)
- [ ] Refresh token rotation: old JTI blacklisted, new JTI issued

**Contact:**

- [ ] `contact.model.ts` exists — contact messages saved to MongoDB
- [ ] `telegramMessageId` field on Contact model — populated after Telegram delivery
- [ ] Telegram notification is non-blocking — never delays HTTP response
- [ ] Dashboard `GET /api/v1/contact` reads from MongoDB, not Telegram

**Appointment:**

- [ ] No `smsLog` field on Appointment model
- [ ] No SMS endpoint exists anywhere
- [ ] WhatsApp notification is non-blocking

**General:**

- [ ] Every async function in `asyncHandler` or try/catch
- [ ] No raw `console.log` — morgan for HTTP, chalk for startup only
- [ ] Every model has indexes on queried fields
- [ ] `sanitizeHtml` called on all TipTap content in service layer
- [ ] Admin seed is idempotent
- [ ] `.env.example` complete — every variable documented
- [ ] CORS only allows two whitelisted origins
- [ ] No stack traces in production error responses
- [ ] All file uploads MIME-validated in multer fileFilter
- [ ] No `require()` calls — ES module `import` syntax only

---

**Begin building now. Start with Step 1 of Section 27. Do not skip any section. Do not omit any file. Build everything. Run `npm run type-check` after each module is complete.**

---

**Architectural Decision Record (ADR): File Uploads**
*Decision:* We have intentionally deviated from the original specification regarding file uploads. Instead of applying multer directly to the create/update routes for entities (Articles, Research, Testimonials), we have implemented a dedicated `POST /api/v1/upload` endpoint.
*Reasoning:* This decouples the file upload process from entity creation/updating, allowing the frontend to use pre-uploaded JSON objects (`{ url, fileId }`) when interacting with entity endpoints. This approach simplifies the frontend interaction, keeps the entity schemas clean, and avoids parsing complex `multipart/form-data` with nested JSON arrays in the backend services.

